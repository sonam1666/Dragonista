# Assets Folder

- Upon downloading and unpackaging Metronic, the assets folder will be empty. Please initialize metronic by installing the build tools and running the gulp task, 
  this will then generate the assets folder along with all the files that's required automatically.

- To get started please open the [Documentation page](//docs/docs.html) or [Online Documentation page](//https://keenthemes.com/metronic/?page=docs) 

- For any theme related questions please contact our [Theme Support](//support@keenthemes.com)


Happy coding with Metronic!